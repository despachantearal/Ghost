# 👻 Ghost Stories Website

Simple horror-themed website project.

## Features
- Dark horror UI
- Interactive scare button
- Simple structure (HTML, CSS, JS)

## How to Use
Open index.html in your browser.

## Author
Created for GitHub upload project.
