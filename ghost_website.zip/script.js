function scare() {
    alert("👻 BOOOO!!! Did I scare you?");
}
